# Calisthenics Lab

Native Android app project (Kotlin + Jetpack Compose).

## Build from your phone using GitHub Actions

1. In your mobile browser, sign in to GitHub and create a **public or private repository** named `CalisthenicsLab`.
2. Upload the **contents** of this ZIP to the repository's `main` branch. Keep the folder structure, including `.github/workflows/build-apk.yml`. Do not upload the ZIP as a single file.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK**, then **Run workflow** if it has not started automatically.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run, scroll to **Artifacts**, and download `CalisthenicsLab-debug-apk`.
7. Extract the downloaded artifact ZIP on your phone. Tap `app-debug.apk` to install it. If Android asks, allow your browser or file manager to install unknown apps.

You can also trigger a build by pushing any commit to `main`.

## App features
- Custom exercise names
- Bodyweight and weighted exercise modes
- Epley, Brzycki and Lander estimated 1RM formulas
- Total-load and estimated added-weight 1RM for weighted exercises
- Locally saved exercise records
- Dark AMOLED-oriented interface

Minimum Android version: Android 8.0 (API 26).

## Calculation note
These are estimates, not tested maximums. For weighted exercises, total load is bodyweight plus external weight.
