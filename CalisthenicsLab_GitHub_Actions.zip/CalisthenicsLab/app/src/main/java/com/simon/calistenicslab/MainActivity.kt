package com.simon.calistenicslab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Bg = Color(0xFF090B0D)
private val Panel = Color(0xFF171B20)
private val Accent = Color(0xFFB6F36A)
private val Muted = Color(0xFF9AA3AD)

data class Record(
    val exercise: String, val type: String, val bodyweight: Double,
    val added: Double, val reps: Int, val total1rm: Double, val external1rm: Double
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("calisthenics_lab", MODE_PRIVATE)
        setContent {
            var records by remember {
                mutableStateOf(loadRecords(prefs.getString("records", "[]") ?: "[]"))
            }
            var exercise by remember { mutableStateOf("Weighted Pull-Up") }
            var type by remember { mutableStateOf("Weighted") }
            var bw by remember { mutableStateOf("50") }
            var load by remember { mutableStateOf("20") }
            var reps by remember { mutableStateOf("5") }
            var formula by remember { mutableStateOf("Epley") }
            var result by remember { mutableStateOf<Record?>(null) }
            var error by remember { mutableStateOf("") }
            var tab by remember { mutableStateOf("Calculator") }

            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Accent,
                onPrimary = Color(0xFF10140B), onBackground = Color.White,
                onSurface = Color.White, secondary = Muted
            )) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    Column(Modifier.fillMaxSize().padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("CALISTHENICS LAB", color = Color.White,
                                    fontSize = 22.sp, fontWeight = FontWeight.Black)
                                Text("STRENGTH • RECORDS • 1RM", color = Muted, fontSize = 10.sp)
                            }
                            Text("BETA 1.0", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatCard("RECORDS", records.size.toString(), Modifier.weight(1f))
                            StatCard("BEST EST. 1RM", records.maxOfOrNull { it.total1rm }?.let { "%.1f kg".format(it) } ?: "—", Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Calculator", "Records").forEach { item ->
                                FilterChip(selected = tab == item, onClick = { tab = item },
                                    label = { Text(item) })
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        if (tab == "Calculator") {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                item { Text("EXERCISE CALCULATOR", color = Accent, fontWeight = FontWeight.Bold) }
                                item { Field("Exercise name", exercise) { exercise = it } }
                                item {
                                    Text("EXERCISE TYPE", color = Muted, fontSize = 11.sp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf("Bodyweight", "Weighted").forEach {
                                            FilterChip(selected = type == it, onClick = { type = it; result = null }, label = { Text(it) })
                                        }
                                    }
                                }
                                if (type == "Weighted") {
                                    item { Field("Bodyweight (kg)", bw, true) { bw = it } }
                                    item { Field("Added weight (kg)", load, true) { load = it } }
                                } else {
                                    item { Field("Effective resistance / load (kg)", load, true) { load = it } }
                                }
                                item { Field("Repetitions (1–30)", reps, true) { reps = it } }
                                item {
                                    Text("FORMULA", color = Muted, fontSize = 11.sp)
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        listOf("Epley", "Brzycki", "Lander").forEach {
                                            FilterChip(selected = formula == it, onClick = { formula = it }, label = { Text(it) })
                                        }
                                    }
                                }
                                item {
                                    Button(onClick = {
                                        val r = reps.toIntOrNull()
                                        val b = bw.toDoubleOrNull()
                                        val w = load.toDoubleOrNull()
                                        if (exercise.isBlank() || r == null || r !in 1..30 || w == null || w < 0 ||
                                            (type == "Weighted" && (b == null || b <= 0))) {
                                            error = "Check the exercise, weight and reps fields."
                                            result = null
                                        } else {
                                            val total = if (type == "Weighted") b!! + w else w
                                            val max = when (formula) {
                                                "Brzycki" -> if (r < 37) total * 36.0 / (37.0 - r) else total
                                                "Lander" -> total * 100.0 / (101.3 - 2.67123 * r)
                                                else -> total * (1.0 + r / 30.0)
                                            }
                                            val body = if (type == "Weighted") b!! else 0.0
                                            result = Record(exercise.trim(), type, body, w, r, max,
                                                if (type == "Weighted") max - body else max)
                                            error = ""
                                        }
                                    }, modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)) {
                                        Text("CALCULATE ESTIMATED 1RM", fontWeight = FontWeight.Bold)
                                    }
                                }
                                if (error.isNotBlank()) item { Text(error, color = Color(0xFFFF7777)) }
                                result?.let { res ->
                                    item {
                                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                                Text("ESTIMATED ONE-REP MAX", color = Muted, fontSize = 11.sp)
                                                Text("%.2f kg".format(res.total1rm), color = Accent, fontSize = 34.sp, fontWeight = FontWeight.Black)
                                                if (res.type == "Weighted") Text("Estimated added weight: %.2f kg".format(res.external1rm), color = Color.White)
                                                Text("${res.exercise} • ${res.reps} reps • $formula", color = Muted, fontSize = 12.sp)
                                                Button(onClick = {
                                                    records = listOf(res) + records
                                                    prefs.edit().putString("records", saveRecords(records)).apply()
                                                    result = null
                                                }, modifier = Modifier.fillMaxWidth()) { Text("SAVE RECORD") }
                                            }
                                        }
                                    }
                                }
                                item {
                                    Text("For weighted movements, total 1RM includes bodyweight. Estimated added weight is shown separately. These are estimates, not tested maximums.",
                                        color = Muted, fontSize = 11.sp)
                                }
                            }
                        } else {
                            if (records.isEmpty()) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text("No records yet. Calculate your first 1RM.", color = Muted)
                                }
                            } else {
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(records) { rec ->
                                        Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                                            Column(Modifier.fillMaxWidth().padding(14.dp)) {
                                                Text(rec.exercise, fontWeight = FontWeight.Bold)
                                                Text("${rec.reps} reps • ${rec.type}", color = Muted, fontSize = 12.sp)
                                                Text("%.2f kg estimated total 1RM".format(rec.total1rm), color = Accent, fontWeight = FontWeight.Bold)
                                                if (rec.type == "Weighted") Text("Added-weight estimate: %.2f kg".format(rec.external1rm), color = Muted, fontSize = 12.sp)
                                            }
                                        }
                                    }
                                    item {
                                        OutlinedButton(onClick = {
                                            records = emptyList()
                                            prefs.edit().remove("records").apply()
                                        }, modifier = Modifier.fillMaxWidth()) { Text("CLEAR ALL RECORDS") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Accent, fontSize = 21.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun Field(label: String, value: String, numeric: Boolean = false, onChange: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label.uppercase(), color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(value, onChange, modifier = Modifier.fillMaxWidth(),
            singleLine = true, keyboardOptions = KeyboardOptions(
                keyboardType = if (numeric) KeyboardType.Decimal else KeyboardType.Text
            ), colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Accent, unfocusedBorderColor = Color(0xFF39414A),
                focusedTextColor = Color.White, unfocusedTextColor = Color.White
            ))
    }
}

private fun saveRecords(records: List<Record>): String {
    val array = JSONArray()
    records.forEach {
        array.put(JSONObject().put("exercise", it.exercise).put("type", it.type)
            .put("bw", it.bodyweight).put("added", it.added).put("reps", it.reps)
            .put("total", it.total1rm).put("external", it.external1rm))
    }
    return array.toString()
}

private fun loadRecords(raw: String): List<Record> = try {
    val arr = JSONArray(raw)
    (0 until arr.length()).map { i ->
        val o = arr.getJSONObject(i)
        Record(o.getString("exercise"), o.getString("type"), o.getDouble("bw"),
            o.getDouble("added"), o.getInt("reps"), o.getDouble("total"), o.getDouble("external"))
    }
} catch (_: Exception) { emptyList() }
